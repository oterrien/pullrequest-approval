package com.sgcib.github.api;

import com.sgcib.github.api.eventhandler.ICommunicationService;
import com.sgcib.github.api.eventhandler.Status;
import lombok.Data;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ActiveProfiles("test2")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = MocksApplication.class)
@WebAppConfiguration
public class PullRequestApprovalControllerTest {

    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    private ICommunicationService communicationService;

    private Map<String, String> parameters;

    private Status status;

    @Before
    public void setup() throws Exception {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();

        parameters = new HashMap<>(10);
        parameters.put("auto_approval.authorized", "true");
        parameters.put("issue_comment", "approved");
        parameters.put("last_state", "pending");
    }

    @Test
    public void issueEventComment_approved_ShouldPostSuccessStatus() throws Exception {

        // Mock communicationService
        {
            when(communicationService.get(anyString(), any(Class.class))).
                    thenCallRealMethod();
                    /*then(invocationOnMock -> {
                        try {
                            String res = communicationService.get(invocationOnMock.getArgumentAt(0, String.class));
                            return JsonUtils.parse(res, invocationOnMock.getArgumentAt(1, Class.class));
                        } catch (Exception e) {
                            failBecauseExceptionWasNotThrown(e.getClass());
                            throw new RuntimeException(e);
                        }
                    });*/

            String pullsUrl = "https://api.github.com/repos/my-owner/my-repository/pulls";
            String pullsUrlResult = TestUtils.readFile("pull-request-test.json", parameters);
            when(communicationService.get(contains(pullsUrl))).
                    thenReturn(pullsUrlResult);

            String statusesUrl = "https://api.github.com/repos/my-owner/my-repository/statuses";
            String statusesUrlResult = TestUtils.readFile("statuses-test.json", parameters);
            when(communicationService.get(contains(statusesUrl))).
                    thenReturn(statusesUrlResult);

            String contentsUrl = "https://api.github.com/repos/my-owner/my-repository/contents";
            String contentsUrlResult = TestUtils.readFile("remote-config-files-test.json", parameters);
            when(communicationService.get(contains(contentsUrl))).
                    thenReturn(contentsUrlResult);

            String downloadUrl = "https://raw.githubusercontent.com/my-owner/my-repository/my-branch";
            String downloadUrlResult = TestUtils.readFile("configuration-test.properties", parameters);
            when(communicationService.get(contains(downloadUrl))).
                    thenReturn(downloadUrlResult);

            when(communicationService.post(contains(statusesUrl), any(Status.class))).
                    then(invocationOnMock -> {
                        status = invocationOnMock.getArgumentAt(1, Status.class);
                        return HttpStatus.OK;
                    });
        }

        String content = TestUtils.readFile("issue-comment-event-test.json", parameters);
        String eventType = "issue_comment";

        // Simulate a calling of webservice
        mockMvc.perform(
                MockMvcRequestBuilders.post("/webhook").
                        content(content).
                        header("x-github-event", eventType));

        // Assertions
        assertThat(status).isNotNull();
        assertThat(status.getState()).isEqualTo(Status.State.SUCCESS.getState());
    }

    @Data
    public class Result {

        private Status status;
    }
}
