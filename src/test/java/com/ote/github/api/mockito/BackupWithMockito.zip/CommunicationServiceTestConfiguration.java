package com.sgcib.github.api;

import com.sgcib.github.api.eventhandler.CommunicationService;
import com.sgcib.github.api.eventhandler.ICommunicationService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

import static org.mockito.Mockito.mock;

@Profile("test2")
@Configuration
public class CommunicationServiceTestConfiguration {

    @Bean
    @Primary
    public ICommunicationService communicationService() {

        return mock(CommunicationService.class);
    }
}